package com.example.clockwidget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.text.format.DateFormat
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class ClockWidgetProvider : AppWidgetProvider() {

    companion object {
        const val ACTION_TICK = "com.example.clockwidget.ACTION_TICK"
        private const val REQUEST_CODE = 1001

        fun updateAllWidgets(context: Context) {
            val mgr = AppWidgetManager.getInstance(context)
            val ids = mgr.getAppWidgetIds(
                android.content.ComponentName(context, ClockWidgetProvider::class.java)
            )
            for (id in ids) {
                updateWidget(context, mgr, id)
            }
        }

        fun updateWidget(context: Context, mgr: AppWidgetManager, widgetId: Int) {
            val cal = Calendar.getInstance()
            val views = RemoteViews(context.packageName, R.layout.clock_widget)

            // Digital clock text
            val is24 = DateFormat.is24HourFormat(context)
            val timeFormat = if (is24) SimpleDateFormat("HH:mm:ss", Locale.getDefault())
                              else SimpleDateFormat("hh:mm:ss", Locale.getDefault())
            val ampmFormat = SimpleDateFormat("a", Locale.getDefault())
            val dateFormat = SimpleDateFormat("EEE  dd.MM.yyyy", Locale.getDefault())

            views.setTextViewText(R.id.digital_time_text, timeFormat.format(cal.time))
            views.setTextViewText(R.id.digital_date_text, dateFormat.format(cal.time).uppercase(Locale.getDefault()))
            if (is24) {
                views.setViewVisibility(R.id.digital_ampm_text, android.view.View.GONE)
            } else {
                views.setViewVisibility(R.id.digital_ampm_text, android.view.View.VISIBLE)
                views.setTextViewText(R.id.digital_ampm_text, ampmFormat.format(cal.time).uppercase(Locale.getDefault()))
            }

            // Analog clock bitmap, using whichever face style this widget was configured with
            val style = WidgetPrefs.loadStyle(context, widgetId)
            val bmp = AnalogClockRenderer.render(320, cal, style)
            views.setImageViewBitmap(R.id.analog_clock_image, bmp)

            // Show/hide each half depending on the widget "type" (Both / Analog only / Digital only)
            val type = WidgetPrefs.loadType(context, widgetId)
            views.setViewVisibility(
                R.id.analog_clock_image,
                if (type == ClockType.DIGITAL_ONLY) android.view.View.GONE else android.view.View.VISIBLE
            )
            views.setViewVisibility(
                R.id.digital_clock_container,
                if (type == ClockType.ANALOG_ONLY) android.view.View.GONE else android.view.View.VISIBLE
            )

            // Settings gear: tapping it reopens the face/style picker for THIS widget instance,
            // so the design can be changed anytime, not just when the widget is first added.
            val configIntent = Intent(context, ClockWidgetConfigureActivity::class.java).apply {
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val configPendingIntent = android.app.PendingIntent.getActivity(
                context, widgetId, configIntent,
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.settings_button, configPendingIntent)

            mgr.updateAppWidget(widgetId, views)
        }

        /** Schedules the next 1-second tick so the second hand and digital seconds stay live. */
        fun scheduleNextTick(context: Context) {
            val intent = Intent(context, ClockWidgetProvider::class.java).apply {
                action = ACTION_TICK
            }
            val pendingIntent = PendingIntent.getBroadcast(
                context, REQUEST_CODE, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val triggerAt = SystemClock.elapsedRealtime() + 1000L
            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pendingIntent
            )
        }

        fun cancelTick(context: Context) {
            val intent = Intent(context, ClockWidgetProvider::class.java).apply {
                action = ACTION_TICK
            }
            val pendingIntent = PendingIntent.getBroadcast(
                context, REQUEST_CODE, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            alarmManager.cancel(pendingIntent)
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        // Note: for a freshly-added widget with a configure Activity, the Activity itself calls
        // updateWidget() once the user confirms a style — onUpdate mainly matters for reboots/
        // periodic refresh of already-configured widgets, which is what this covers.
        updateAllWidgets(context)
        scheduleNextTick(context)
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        for (id in appWidgetIds) {
            WidgetPrefs.deleteAll(context, id)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_TICK,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_DATE_CHANGED -> {
                updateAllWidgets(context)
                scheduleNextTick(context)
            }
        }
    }

    override fun onEnabled(context: Context) {
        scheduleNextTick(context)
    }

    override fun onDisabled(context: Context) {
        cancelTick(context)
    }
}
