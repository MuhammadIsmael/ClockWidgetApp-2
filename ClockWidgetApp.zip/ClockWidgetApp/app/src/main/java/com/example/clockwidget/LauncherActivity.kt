package com.example.clockwidget

import android.app.Activity
import android.os.Bundle
import android.widget.Toast

/**
 * This app has no real UI — it only provides a home-screen widget.
 * Opening the app icon just explains that and closes.
 */
class LauncherActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Toast.makeText(
            this,
            "Long-press your home screen \u2192 Widgets \u2192 Clock Widget to add it.",
            Toast.LENGTH_LONG
        ).show()
        finish()
    }
}
